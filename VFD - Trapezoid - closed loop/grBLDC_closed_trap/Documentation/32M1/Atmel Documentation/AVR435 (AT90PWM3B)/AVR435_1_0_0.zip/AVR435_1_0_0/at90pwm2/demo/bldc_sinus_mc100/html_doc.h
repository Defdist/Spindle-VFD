/*!
* \mainpage
* \section section1 Description
*   This application drives a BLDC motor with sinusoidal waveforms\n
*   The motor features Hall sensors \n
*   It runs on an ATAVRMC100 board with an AT90PWM3B part\n
*   The main source files are :
*
*         -  main.c             main loop
*         -  mc_control.c       PI regulation
*         -  mc_drv.c           hardware level of motor control
*
*         -  mc_interface.c     interface routines to motor control
*
*         -  ushell_task.c      command interpreter from an ascii chain
*         -  ascii.c            ascii to binaire conversion
*         -  uart_lib.c         communication through AT90PWM3 Uart
*
*   This application can be compiled with IAR or with GCC\n
*   Be careful : the minimum timer 0 period with GCC must be set to 64uS\n
*                     in mc_drv.c file\n
*                with IAR the minimum timer 0 period can be set to 48uS\n
*                     this will increase the sinus waveform resolution\n
* \section section2 Preamble
* All parameters are given for the motor included in the kit with no load.\n
* They must be ajusted according to the application (motor, load ...)\n
* This application is configured in open loop. The maximum allowed speed setting \n
* with the ss command is 0x250. [>ss 250 ]\n
* The speed loop regulator parameters and function are dedicated for a 110V motor\n
* running on an MC200 board. They must be adjusted for the application motor and\n
* load.\n
*   The rotor position angle is estimated from the Hall sensor transitions.\n
*   It induces the following constraints:\n
*       1) At start up of the motor, the speed must be set at a low value (0x80)\n
*       2) The acceleration must be smooth, otherwice the motor will desynchronized\n
*                and the current will go in an overcurrent area.\n
* \n
*
* \section section3 Main Peripheral Use
*   - Timer 0 is used for speed measurement/main tick/svpwm \n
*   - Timer 1 is not used \n
*   - PSC0,1,2 are used to generate PWM \n
*   - ADC is used for current measurement \n
*
* \section section4 User Manual
*  The serial interface signals (RxD-TxD) are available on the ext connector\n
*  They come directly from the microcontroller, so they have to be adapter with\n
*    a RS232 converter. An ATMEL STK500 board can provide the converter function\n
*    In that case : connect the IO-CON pin 7 to TxD of the STK500 RS232 spare connector\n
*               and connect the IO-CON pin 8 to RxD of the STK500 RS232 spare connector
*
* \subsection subsection1 List of Material
*   - ATAVRMC100 (AT90PWM3B clock is 16MHz from PLL)
*   - STK500 (used to provide an RS232 adaptation)
*
* \subsection subsection2 Hardware Configuration
*   - Connect ATAVRMC100 to STK500 RS232 SPARE connector
*   - Set the ATAVRMC100 jumpers to 'sensor' location
*
* \subsection subsection3 HyperTerminal Configuration
*   - Speed : 38400 bauds
*   - Bits : 8
*   - Stop : 1
*   - Handshake : None
*   - Parity : None
*
* \subsection subsection4 List of Commands
* After reset the ATAVRMC100 board prints the welcome message and a prompt\n
* The user commands are :
*   - ru   : run / start the motor
*   - st   : stop / stop the motor
*   - help : help / return the list of commands
*   - fw   : forward
*   - bw   : backward
*   - ss v : set speed (v is the value)
*   - gi   : get identification / return the board id, the soft id and the soft rev
*   - g0   : get status 0 : return the status byte, the speed and the current
*   - g1   : get status 1 : return the rotation counter
* \n \n
* Note : All values are in hexadecimal form
*/
