//!
//! @file $RCSfile: main.c,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! @brief Main module : It is based on an infinite loop
//!
//! @version $Revision: 1.6 $
//!

//_____  I N C L U D E S ___________________________________________________


#ifdef __ICCAVR__ // IAR C Compiler
#include "config.h"
#include "lib_mcu/compiler.h"
#include "lib_mcu/mcu.h"
#include "lib_mcu/adc/adc_drv.h"
#include "mc_interface.h"
#include "inavr.h"
#include <stdio.h>
#endif

#ifdef __GNUC__  // GNU C Compiler
#include "config_for_gcc.h"
#include <avr/io.h>
#include "mc_interface.h"
#endif



//_____ M A C R O S ________________________________________________________


//_____ D E F I N I T I O N S ______________________________________________
void   init(void);
void   ADC_Init(void);
void   ADC_start_conv(void);
void   ushell_task_init(void);
void   ushell_task(void);
void   PSC_Init(unsigned int ot0,  unsigned int ot1);
//void   PSC_Start(void);
U16    mc_control_speed_16b(U16 speed_ref , U16 speed_measure);
U16    get_Hall_Period(void);
void   store_new_amplitude(U16 new_val);
S16    read_acquisition(void);
void   Start_ADC(void);


//_____ D E C L A R A T I O N S ____________________________________________
volatile U8     Main_Tick = 0; //!< Periodic clock to generate
volatile S16    Ref_Speed = 0; //!< Reference speed from user

extern volatile U8   Flag_IT_ADC;
extern volatile S16  User_Speed;
extern volatile U16  Measured_Speed;
extern volatile Bool mci_run_stop;


int main(void)
{

   init();

   ADC_Init();

   ushell_task_init();

   PSC_Init(2, MAX_PWM);

//   PSC_Start(); /* for the first time MC100*/


   while(1)
   {

      if (Main_Tick)
      {
         Main_Tick=0;
//         Start_ADC();

         if (mci_run_stop == RUN)
         {
            Ref_Speed = User_Speed;
         }
         else
         {
            Ref_Speed = 0;
         }

         Measured_Speed = (U16)K_SPEED / get_Hall_Period();
         mci_store_measured_speed((U8)Measured_Speed);

         #if (REGULATION_MODE == 2)
            store_new_amplitude( mc_control_speed_16b((U16) Ref_Speed , (U16) Measured_Speed) );
         #else
            if (mci_run_stop == RUN)
            {

//               store_new_amplitude( AMPLITUDE_IN_OPEN_LOOP );
               store_new_amplitude( Ref_Speed );
            }
            else
            {
               store_new_amplitude( 0 );
            }
         #endif
         ushell_task();
      }

      if (Flag_IT_ADC)
      {

         mci_store_measured_current(read_acquisition());

         Flag_IT_ADC=0;
      }   /* end of Flag_IT_ADC */

#ifdef MC200
      /* test the overcurrent input MC200 */
      if (( PIFR0 & (1<<PEV0A)) !=0 )
      {
         /* fault on overcurrent */
         Set_PC3();   /* switch on the overcurrent led */
         Clear_PE1(); /* switch off the run/stop led */
         while (1) ;  /* infinite loop */
      }
#endif

   }     /* end of while(1) */
}        /* end of main */


