//!
//! @file $RCSfile: init.c,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! @brief Initialization of peripherals
//!
//! @version $Revision: 1.5 $
//!

//_____  I N C L U D E S ___________________________________________________

#ifdef __ICCAVR__ // IAR C Compiler
#include "config.h"
#include "inavr.h"
#endif

#ifdef __GNUC__  // GNU C Compiler
#include "config_for_gcc.h"
#include <avr/io.h>
#endif

#include "lib_mcu/comparator/comparator_drv.h"


/**
* @brief ports direction configuration, timer 0 configuration, run the PLL, allow interruptions
*/
void init(void)
{
   /*************************************************************************************/
   /*           ports direction configuration                                           */
   /*************************************************************************************/

   DDRB = 0xC3;
//   DDRC = 0x89; MC200
   DDRC = 0x8A; //MC100
   DDRD = 0x01;
//   DDRE = 0x02; // MC200
   DDRE = 0x04; // MC100

   PORTC = 0x06;     /* enable pull up */

   /*************************************************************************************/
   /*     Timer 0 Configuration : generates the sampling fr�quency                      */
   /*************************************************************************************/
   TCCR0A = (1<<WGM01);   // mode CTC : Clear Timer on Compare
   TCCR0B = (1<<CS02);    // f_quartz = 8 MHz / 256 = 32 kHz
//      OCR0A = 0x20;          // one interruption every 1.056ms @8 Mhz
//      OCR0A = 0x10;          // one interruption every 0.544ms @8 Mhz
//      OCR0A = 0x08;          // one interruption every 0.288ms @8 Mhz (0.144ms @16 Mhz)
//   OCR0A = 0x02;          // one interruption every 48�S @16 Mhz
   OCR0A = 0x03;          // one interruption every 64�S @16 Mhz

// !! 48�S is too quick for GCC , please use at least 64�S 
//                                and adjust Prescaler_Main_Tick
//                                in mc_drv.c


   TIMSK0 = (1<<OCIE0A);  // allow interruption when timer=compare

   init_comparator0();
   init_comparator1();
   init_comparator2();


//    initialize external interrupts /* MC200 */

//   EICRA =(0<<ISC21)|(1<<ISC20)|(0<<ISC11)|(1<<ISC10)|(0<<ISC01)|(1<<ISC00);
//   EIFR = (1<<INTF2)|(1<<INTF1)|(1<<INTF0); // clear possible IT due to config
//   EIMSK=(0<<INT2)|(1<<INT1)|(1<<INT0);

   Enable_interrupt();            // allow interruptions
}
