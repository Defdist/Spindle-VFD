//!
//! @file $RCSfile: adc.c,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! @brief Initialize and Read ADC functions
//!
//! @version $Revision: 1.5 $
//!

//_____  I N C L U D E S ___________________________________________________
#ifdef __ICCAVR__ // IAR C Compiler
#include "config.h"
#include "inavr.h"
#endif

#ifdef __GNUC__  // GNU C Compiler
#include "config_for_gcc.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#endif
#include "adc.h"


//_____ M A C R O S ________________________________________________________


//_____ D E F I N I T I O N S ______________________________________________



//_____ D E C L A R A T I O N S ____________________________________________
volatile U8   Flag_IT_ADC = 0 ;



//! @brief Initialisation of the ADC
//!
//!
//! @param none
//! @pre none
//! @return none
//!/
void ADC_Init(void)
{

   /* Digital Input Disable Register 0 */
   DIDR0 =   (0<<ADC7D) \
           | (0<<ADC6D ) \
           | (0<<ADC5D ) \
           | (0<<ADC4D ) \
           | (0<<ADC3D ) \
           | (0<<ADC2D ) \
           | (0<<ADC1D ) \
           | (0<<ADC0D ) \
   ;

   /* Digital Input Disable Register 1 */
   DIDR1 =   (0<<ACMP0D) \
           | (1<<AMP0PD) /* disable digital input on AMP 0 */ \
           | (1<<AMP0ND) /* disable digital input on AMP 0 */ \
           | (0<<ADC10D) \
           | (1<<ADC9D)  \
           | (1<<ADC8D)
   ;

   /* init amplifier 0 */
   AMP0CSR =   (1 <<AMP0EN)  /* Amplifier enable */ \
             | (0 <<AMP0IS) \
             | (AMP_GAIN_5 <<AMP0G0) \
             | (AMP_TRIG_ON_PSC0 <<AMP0TS0) \
   ;

   /* init amplifier 1 */
   AMP1CSR =   (1 <<AMP1EN)  /* Amplifier enable */ \
             | (0 <<AMP1IS) \
             | (AMP_GAIN_5 <<AMP1G0) \
             | (AMP_TRIG_ON_PSC0 <<AMP1TS0) \
   ;

   /* init ADC */
   ADMUX =    (ADC_VREF_INTERNAL <<REFS0) \
            | (0 <<ADLAR) \
            | (ADC_INPUT_AMP1 <<MUX0) /* select input */ \
   ;

   ADCSRB =   (1<<ADHSM)  /* High Speed Mode   */ \
            | (0<<ADASCR) /* not used on AT90PWM3B */ \
            | (ADC_TRIG_SRC_FREE_RUNNING <<ADTS0) \
   ;

   ADCSRA =   (1<<ADEN)  /* ADC enable          */ \
            | (0<<ADSC)  \
            | (0<<ADATE) \
            | (1<<ADIE)  /* interrupt enable    */ \
            | (ADC_PRESCALER_16 <<ADPS0) \
   ;

}


//! @brief Start the ADC conversion
//!
//!
//! @param none
//! @pre none
//! @return none
//!/
void   Start_ADC(void)
{
   ADCSRA =   (1<<ADEN)  /* ADC enable          */ \
            | (1<<ADSC)  /* start conversion */ \
            | (0<<ADATE) \
            | (1<<ADIE)  /* interrupt enable    */ \
            | (ADC_PRESCALER_16 <<ADPS0) \
   ;

}


//! @brief Get the ADC conversion result
//!
//!
//! @param none
//! @pre none
//! @return 16 bit result
//!/
S16 read_acquisition(void)
{
   Union16     resultADC ;

   LSB(resultADC) = ADCL ;  // the ADC output has 10 bit resolution
   MSB(resultADC) = ADCH ;

   return (resultADC.w) ;
}


//! @brief Set the ADC flag when conversion is done
//!
//! @param  none
//! @pre    none
//! @return none
//!/
#ifdef __ICCAVR__ // IAR C Compiler
#pragma vector = ADC_vect
__interrupt void Read_Measure(void)
#endif
#ifdef __GNUC__  // GNU C Compiler
ISR(ADC_vect)
#endif
{
   Flag_IT_ADC=1;
}

