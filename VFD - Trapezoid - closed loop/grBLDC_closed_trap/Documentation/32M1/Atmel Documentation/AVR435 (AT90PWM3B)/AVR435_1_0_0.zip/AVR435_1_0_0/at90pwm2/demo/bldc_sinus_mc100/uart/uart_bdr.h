/*H**************************************************************************
* $RCSfile: uart_bdr.h,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: mc100_bldc_sinus_1_0_0 $
* REVISION:     $Revision: 1.1 $
* FILE_CVSID:   $Id: uart_bdr.h,v 1.1 2008/09/16 15:49:06 raubree Exp $
*----------------------------------------------------------------------------
* PURPOSE:
* Provide Baudrate configuration for MCU
*****************************************************************************/
#ifndef _UART_BDR_H
#define _UART_BDR_H
 
#ifndef __GNUC__
   #define Uart_set_baudrate(bdr)  ( UBRRH = (Uchar)((((Uint32)FOSC*1000L)/((Uint32)bdr*16)-1)>>8),\
                                  UBRRL = (Uchar)(((Uint32)FOSC*1000 )/((Uint32)bdr*16)-1)    )
#else
  #define Uart_set_baudrate(bdr)  ( UBRR = (U16)(((U32)FOSC*1000L)/((U32)bdr*16)-1))
#endif

#define Uart_double_bdr()          (UCSRA |= (1<<U2X1))

#endif/* _UART_BDR_H */

