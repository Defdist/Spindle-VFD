/*C**************************************************************************
* $RCSfile: uart_lib.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: mc100_bldc_sinus_1_0_0 $
* REVISION:     $Revision: 1.1 $
* FILE_CVSID:   $Id: uart_lib.c,v 1.1 2008/09/16 15:49:06 raubree Exp $
*----------------------------------------------------------------------------
* PURPOSE:
* This file provides a minimal VT100 terminal access through UART
* and compatibility with Custom I/O support
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/

#ifdef __ICCAVR__ // IAR C Compiler
#include "config.h"
#endif

#ifdef __GNUC__  // GNU C Compiler
#include "config_for_gcc.h"
#include <avr/io.h>
#endif

#include "uart_lib.h"


/*_____ G L O B A L    D E F I N I T I O N _________________________________*/


/*_____ D E F I N I T I O N ________________________________________________*/

/*_____ M A C R O S ________________________________________________________*/


bit uart_test_hit (void)
{
return Uart_rx_ready();
}


bit uart_init (void)
{
#ifndef UART_U2
  Uart_set_baudrate(BAUDRATE);
  Uart_hw_init(UART_CONFIG);
#else
  Uart_set_baudrate(BAUDRATE/2);
  Uart_double_bdr();
  Uart_hw_init(UART_CONFIG);

#endif
  Uart_enable();
  return TRUE;
}


r_uart_ptchar uart_putchar (p_uart_ptchar ch)
{
  while(!Uart_tx_ready());
  Uart_set_tx_busy(); // Set Busy flag before sending (always)
  Uart_send_byte(ch);
	
  return ch;
}




r_uart_gtchar uart_getchar (void)
{
  register char c;

  while(!Uart_rx_ready());
  c = Uart_get_byte();
  Uart_ack_rx_byte();
  return c;
}


